from django.contrib import admin
from booking.models import*

# Register your models here.
admin.site.register(TicketClass)
admin.site.register(Discount)
